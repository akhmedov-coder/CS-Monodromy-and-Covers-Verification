# Verification for Section 7

This directory contains exact calculations for the symmetric bicanonical pencil
in *A monodromy relation for the Cartwright--Steger fibration*.

The input files `equations85.txt`, `P9.txt`, and `Q9.txt` are the polynomial
equations and Albanese-coordinate forms from the ancillary data accompanying
Z. Szabó, *A polynomial formula for the Albanese map of the Cartwright--Steger
surface* (arXiv:2609.23124v1). The 85 equations are the Borisov--Yeung
bicanonical equations, in Szabó's stated order. The original sources are
L. A. Borisov and S.-K. Yeung, *Explicit equations of the Cartwright--Steger
surface* (arXiv:1804.00737v6), and Szabó's ancillary data.

SHA-256 checksums of the three input files, in that order:

```
3c2b0487c765454628c24b2d0704581fe4a81a15604354746dcd671ae0dce18c  equations85.txt
8142fe382e5a5e8dc16845ae141312b984b72fcb7980acb2bd469b6090661495  P9.txt
b5f47ccf6e02dd2f100d7041c8c5c600b25b1e39d609a16643ad07a349525518  Q9.txt
```

Requires Python 3 and SymPy. From this directory run `python3 run_all.py`.
The scripts use rational arithmetic; no floating-point test is used.

* `gb_weight2_Q.py` restricts to `U7=U8=1, U9=-2`, checks length 24,
  and checks that multiplication by `U0` has squarefree characteristic polynomial.
* `check_wt0_U3.py` checks that the homogeneous scheme with
  `U3=U7=U8=U9=0` has no nonzero point.
* `gb_zero_wt_chart_Q.py` computes length 12 in the remaining chart `U3=1`.
* `check_D_fixed.py` checks that `dL0` is nonzero at the six fixed points
  and that the two pencil differentials are proportional there.
* `check_simple_branch.py` checks that `Q9` is nonzero there and that
  the quadratic coefficient of `x=P9/Q9` on `D0` is nonzero at all six.
* `check_node_tangent.py` uses equations numbered `13,74,45,57,2,80,56`
  from zero and the real node with `theta^3=1116`. It verifies the exact
  determinant and the two coefficients of `dU7` used in Section 6.

The last script works in the coordinate ring of the six fixed points.
It selects a nowhere-zero tangent vector in the weight-one eigenspace,
solves the weight-two second-order tangent equations subject to `L0=0`,
and checks that the resulting quadratic coefficient is a unit. A unit
test means adjoining that coefficient to the fixed-point ideal gives
the unit ideal, so it is nonzero at every fixed point.

The three nodes are the intersection of the Cartwright--Steger surface
with the line `[2:1:3:12:0:0:0:-s:-s:2s]`, where `s^3=1116`;
their local nonaxial tangent calculation is in Section 6 of the paper.

For Proposition 7.3, run python3 check_albanese_fox.py. The file
cky_pi_relators.txt transcribes the thirteen relators of the
Cartwright--Koziarz--Yeung presentation in their published Magma file.
The script computes the Fox derivatives with Albanese weights
(s*t^3, s^-2*t, s^-1*t^-1). Four normalized minors have Groebner
basis (s^4,t) off s*t=1; the indicated minors on that line have
greatest common divisor s-1. It also verifies rank one at (1,1).
This check requires SymPy and makes no claim to determine the marked
handle monodromy.
