from pathlib import Path
import sympy as s,time
u=s.symbols('U0:10');loc={str(x):x for x in u};t=time.time()
es=[s.sympify(ln.replace('^','**'),locals=loc) for ln in open(str(Path(__file__).with_name('equations85.txt'))) if ln.strip() and not ln.startswith('#')]
sub={u[3]:0,u[7]:0,u[8]:0,u[9]:0};fs=[s.expand(e.subs(sub)) for e in es];fs=[f for f in fs if f!=0]
v=list(u[:3])+list(u[4:7]);g=s.groebner(fs,*v,order='grevlex')
print('U3=0 homogeneous cone zero-dimensional?',g.is_zero_dimensional,'GB',len(g.polys),'time',time.time()-t)

assert g.is_zero_dimensional
