"""Check the exact seven-equation tangent calculation at the real node."""
from pathlib import Path
import sympy as s

ROOT = Path(__file__).resolve().parent
u = s.symbols("U0:10")
theta = s.symbols("theta")
loc = {str(x): x for x in u}
eqs = [
    s.sympify(line.replace("^", "**"), locals=loc)
    for line in (ROOT / "equations85.txt").read_text().splitlines()
    if line.strip() and not line.startswith("#")
]
node = {
    u[0]: 1, u[1]: s.Rational(1, 2), u[2]: s.Rational(3, 2),
    u[3]: 6, u[4]: 0, u[5]: 0, u[6]: 0,
    u[7]: -theta / 2, u[8]: -theta / 2, u[9]: theta,
}
indices = [13, 74, 45, 57, 2, 80, 56]
J = s.Matrix([
    [s.expand(s.diff(eqs[i], u[j]).subs(node)) for j in range(1, 8)]
    for i in indices
])
red = lambda x: s.rem(s.Poly(s.expand(x), theta),
                      s.Poly(theta**3 - 1116, theta)).as_expr()
det = red(J.det(method="domain-ge"))
expected = -26504212164176875073986447937805414466800000 * theta
assert det == expected
for j, coefficient in ((8, -s.Rational(12, 29)),
                       (9, -s.Rational(36, 29))):
    rhs = s.Matrix([
        s.expand(s.diff(eqs[i], u[j]).subs(node)) for i in indices
    ])
    cramer = J.copy()
    cramer[:, 6] = -rhs
    assert red(red(cramer.det(method="domain-ge")) - coefficient * det) == 0
print("Node determinant and dU7 = -(12 dU8 + 36 dU9)/29 verified")
