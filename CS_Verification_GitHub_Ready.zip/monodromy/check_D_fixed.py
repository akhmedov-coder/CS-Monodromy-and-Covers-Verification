from pathlib import Path
import sympy as s,itertools,time
u=s.symbols('U0:10'); X,Y,Z=u[0],u[1],u[2]; loc={str(x):x for x in u}
es=[s.sympify(ln.replace('^','**'),locals=loc) for ln in open(str(Path(__file__).with_name('equations85.txt'))) if ln.strip() and not ln.startswith('#')]
sub={u[i]:0 for i in range(4,10)};sub[u[3]]=1
fixed=[s.expand(e.subs(sub)) for e in es];fixed=[e for e in fixed if e!=0]
print('fixed ideal size',len(fixed),flush=True)
rows=[]
for i,e in enumerate(es):
 row=[s.expand(s.diff(e,u[j]).subs(sub)) for j in (7,8,9)]
 if any(x!=0 for x in row):rows.append((i,row))
print('weight2 rows',len(rows),flush=True)
for (i,a),(j,b) in itertools.combinations(rows,2):
 d=s.expand(s.det(s.Matrix([a,b,[1,1,1]])))
 if d==0:continue
 g=s.groebner(fixed+[d],X,Y,Z,order='lex')
 if any(p.as_expr()==1 for p in g.polys):
  print('CERTIFICATE pair',i,j,'det',s.factor(d),flush=True)
  break
else:raise AssertionError('No single pair certificate')
