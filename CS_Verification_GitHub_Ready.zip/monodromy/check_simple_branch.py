from pathlib import Path
import sympy as s,itertools,time
u=s.symbols('U0:10'); X,Y,Z=u[0],u[1],u[2]; loc={str(x):x for x in u}
es=[s.sympify(ln.replace('^','**'),locals=loc) for ln in open(str(Path(__file__).with_name('equations85.txt'))) if ln.strip() and not ln.startswith('#')]
P=s.sympify(open(str(Path(__file__).with_name('P9.txt'))).readlines()[-1].replace('^','**'),locals=loc)
Q9=s.sympify(open(str(Path(__file__).with_name('Q9.txt'))).readlines()[-1].replace('^','**'),locals=loc)
sub={u[i]:0 for i in range(4,10)};sub[u[3]]=1
fixed=[s.expand(e.subs(sub)) for e in es];fixed=[e for e in fixed if e!=0]
g=s.groebner(fixed,X,Y,Z,order='lex',domain=s.QQ)
def red(p):return s.expand(g.reduce(s.expand(p))[1])
rows1=[]
for i,e in enumerate(es):
 a=[red(s.diff(e,u[j]).subs(sub)) for j in (4,5,6)]
 if any(x!=0 for x in a):rows1.append((i,a))
print('weight1 rows',len(rows1),flush=True)
q=s.groebner([p.as_expr() for p in g.polys]+[red(Q9.subs(sub))],X,Y,Z,order='lex')
assert q.polys[0].as_expr()==1
print('Q9 is nonzero at all six fixed points',flush=True)
for (i,a),(j,b) in itertools.combinations(rows1,2):
 v=s.Matrix(a).cross(s.Matrix(b)); vr=[red(t) for t in v]
 if all(x==0 for x in vr):continue
 if s.groebner([p.as_expr() for p in g.polys]+vr,X,Y,Z,order='lex').polys[0].as_expr()==1:
  print('weight1 pair',i,j,'v nonzero at all six',flush=True); assert all(red(sum(row[k]*vr[k] for k in range(3)))==0 for _,row in rows1);break
else: raise AssertionError('No nowhere-zero weight-one tangent vector found')
# Evaluate coefficient in algebraic coordinate ring; use polynomial reduction each operation.
v=s.Matrix(vr)
def hess(e):
 return red(sum(s.diff(e,u[j],u[k]).subs(sub)*v[j-4]*v[k-4] for j in (4,5,6) for k in (4,5,6)))
A=s.Matrix([[red(s.diff(es[i],u[j]).subs(sub)) for j in (7,8,9)] for i in (0,58)]+[[1,1,1]])
assert s.groebner([p.as_expr() for p in g.polys]+[red(A.det())],X,Y,Z,order='lex').polys[0].as_expr()==1
print('weight2 selected matrix determinant is a unit',flush=True)
det=red(A.det()); adj=A.adjugate().applyfunc(red)
rhs=s.Matrix([-hess(es[0]),-hess(es[58]),0])
w_num=(adj*rhs).applyfunc(red)
N=red(sum(red(s.diff(P,u[j]).subs(sub))*w_num[j-7] for j in (7,8,9))+det*hess(P))
print('N reduced coefficient count=',len(str(N)),flush=True)
t=s.groebner([p.as_expr() for p in g.polys]+[N],X,Y,Z,order='lex')
assert t.polys[0].as_expr()==1
print('N unit: True',flush=True)
