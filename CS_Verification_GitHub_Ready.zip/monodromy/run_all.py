"""Run the exact Section 7 verification scripts in their stated order."""
from pathlib import Path
import hashlib
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
CHECKSUMS = {
    "equations85.txt": "3c2b0487c765454628c24b2d0704581fe4a81a15604354746dcd671ae0dce18c",
    "P9.txt": "8142fe382e5a5e8dc16845ae141312b984b72fcb7980acb2bd469b6090661495",
    "Q9.txt": "b5f47ccf6e02dd2f100d7041c8c5c600b25b1e39d609a16643ad07a349525518",
}
for name, expected in CHECKSUMS.items():
    actual = hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
    assert actual == expected, (name, actual)
print("Input checksums verified", flush=True)
for name in (
    "check_node_tangent.py",
    "gb_weight2_Q.py",
    "check_wt0_U3.py",
    "gb_zero_wt_chart_Q.py",
    "check_D_fixed.py",
    "check_simple_branch.py",
):
    print("Running", name, flush=True)
    subprocess.run([sys.executable, str(ROOT / name)], check=True, cwd=ROOT)
print("All exact checks passed", flush=True)
