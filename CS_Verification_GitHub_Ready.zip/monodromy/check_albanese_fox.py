"""Fox-matrix check for Proposition 7.3.

The thirteen relators in cky_pi_relators.txt are copied, in order, from
Cartwright--Koziarz--Yeung's cs-surface-presentations_magma.txt, lines 223--235:
https://www.maths.usyd.edu.au/u/donaldc/cs-surface/cs-surface-presentations_magma.txt
The generators there are simultaneous conjugates of the paper's a1,a2,a3;
their relators give the same abstract presentation and Albanese character.
Run: python3 check_albanese_fox.py
Requires sympy.
"""
from itertools import combinations
from pathlib import Path
import re
import sympy as sp

s, t = sp.symbols("s t")
words = (Path(__file__).with_name("cky_pi_relators.txt")).read_text().splitlines()
assert len(words) == 13
weights = (s*t**3, s**-2*t, s**-1*t**-1)


def fox(word):
    prefix = sp.Integer(1)
    derivatives = [sp.Integer(0) for _ in range(3)]
    for token in word.split("*"):
        match = re.fullmatch(r"a([123])(i?)(?:\^(\d+))?", token)
        assert match, token
        index = int(match[1]) - 1
        exponent = -1 if match[2] else 1
        for _ in range(int(match[3] or "1")):
            if exponent == 1:
                derivatives[index] += prefix
                prefix *= weights[index]
            else:
                prefix /= weights[index]
                derivatives[index] -= prefix
    assert sp.cancel(prefix) == 1
    return [sp.cancel(x) for x in derivatives]


def clear_laurent_monomial(expr):
    numerator = sp.fraction(sp.cancel(expr))[0]
    terms = sp.expand(numerator).as_ordered_terms()
    min_s = min(term.as_powers_dict().get(s, 0) for term in terms)
    min_t = min(term.as_powers_dict().get(t, 0) for term in terms)
    return sp.Poly(
        sp.expand(numerator * s**max(0, -min_s) * t**max(0, -min_t)),
        s, t,
    ).as_expr()


rows = [fox(word) for word in words]


def minor(row_a, row_b, col_a, col_b):
    return sp.cancel(
        rows[row_a][col_a]*rows[row_b][col_b]
        - rows[row_a][col_b]*rows[row_b][col_a]
    )


# Row and column indices are zero based here.
off_line = [
    clear_laurent_monomial(minor(a, b, 0, 1)/(s*t-1))
    for a, b in ((0, 1), (0, 2), (1, 2), (0, 3))
]
gb = sp.groebner(off_line, s, t, order="lex")
assert [p.as_expr() for p in gb.polys] == [s**4, t], gb
print("Off st=1: normalized minors have Groebner basis (s^4,t).")

gcd_on_line = None
for a, b, i, j in ((0, 1, 0, 2), (0, 2, 0, 2), (0, 1, 1, 2)):
    numerator = sp.fraction(sp.cancel(minor(a, b, i, j).subs(t, 1/s)))[0]
    polynomial = sp.Poly(numerator, s)
    gcd_on_line = polynomial if gcd_on_line is None else sp.gcd(
        gcd_on_line, polynomial
    )
assert sp.factor(gcd_on_line.as_expr()) == s-1, gcd_on_line
print("On st=1: the selected minor numerators have gcd s-1.")

at_one = sp.Matrix([
    [entry.subs({s: 1, t: 1}) for entry in row] for row in rows
])
assert at_one.rank() == 1
print("At (1,1): Fox rank 1; elsewhere on (C*)^2: rank 2.")
