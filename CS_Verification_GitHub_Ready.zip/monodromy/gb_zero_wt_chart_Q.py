from pathlib import Path
import sympy as s,time
u=s.symbols('U0:10');loc={str(x):x for x in u};t=time.time()
es=[s.sympify(ln.replace('^','**'),locals=loc) for ln in open(str(Path(__file__).with_name('equations85.txt'))) if ln.strip() and not ln.startswith('#')]
sub={u[3]:1,u[7]:0,u[8]:0,u[9]:0}; fs=[s.expand(e.subs(sub)) for e in es];fs=[f for f in fs if f!=0]
v=list(u[:3])+list(u[4:7]);g=s.groebner(fs,*v,order='grevlex')
lead=[p.LM(order='grevlex').exponents for p in g.polys]
def std(e):return all(not all(ej>=lj for ej,lj in zip(e,l)) for l in lead)
seen={(0,)*6};front=list(seen)
while front:
 e=front.pop()
 for i in range(6):
  ee=list(e);ee[i]+=1;ee=tuple(ee)
  if ee not in seen and std(ee):seen.add(ee);front.append(ee)
print('U3=1 deg',len(seen),'t',time.time()-t,flush=True)


assert g.is_zero_dimensional and len(seen)==12
