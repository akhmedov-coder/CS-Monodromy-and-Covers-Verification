from pathlib import Path
import sympy as s,time,sys
p=7;t=time.time();u=s.symbols('U0:10');loc={str(x):x for x in u}
es=[s.sympify(ln.replace('^','**'),locals=loc) for ln in open(str(Path(__file__).with_name('equations85.txt'))) if ln.strip() and not ln.startswith('#')]
sub={u[7]:1,u[8]:1,u[9]:-2};fs=[s.expand(e.subs(sub)) for e in es];fs=[f for f in fs if f!=0]
print('parsed',len(fs),time.time()-t,flush=True)
g=s.groebner(fs,*u[:7],order='grevlex')
print('GB',len(g.polys),'zero-dim',g.is_zero_dimensional,'t',time.time()-t,flush=True)

lead=[p.LM(order="grevlex").exponents for p in g.polys]
def std(e):return all(not all(ej>=lj for ej,lj in zip(e,l)) for l in lead)
seen={(0,)*7};front=list(seen)
while front:
 e=front.pop()
 for i in range(7):
  ee=list(e);ee[i]+=1;ee=tuple(ee)
  if ee not in seen and std(ee):seen.add(ee);front.append(ee)
print('affine degree',len(seen),flush=True)


base=sorted(seen,key=lambda e:(sum(e),e));ix={e:i for i,e in enumerate(base)};M=s.zeros(len(base));vars=list(u[:7])
for j,e in enumerate(base):
 f=vars[0]*s.prod(v**k for v,k in zip(vars,e));rem=g.reduce(f)[1];pp=s.Poly(rem,*vars,domain=s.QQ)
 for mon,c in pp.terms():M[ix[mon],j]=c
print('mult matrix built',time.time()-t,flush=True)
p=M.charpoly().as_expr()
print('U0 characteristic squarefree?',s.gcd(p,s.diff(p,s.symbols('lambda')))==1,'t',time.time()-t,flush=True)

assert g.is_zero_dimensional and len(seen)==24
assert s.gcd(p,s.diff(p,s.symbols('lambda')))==1
