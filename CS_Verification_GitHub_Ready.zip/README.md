# Verification for Monodromy and finite covers of the Cartwright–Steger surface

Anar Akhmedov and Sai-Kee Yeung

This repository contains the exact verification programs and input data for
the paper. It contains no manuscript drafts. The `covers/` directory concerns
finite covers, integral homology, the lifting obstruction, and fiber divisibility.
The `monodromy/` directory concerns the bicanonical pencil, the local node tangent
calculation, and the Albanese Fox matrix.

## Requirements

Python 3 and SymPy. The checks below were rerun with SymPy 1.14.0.

```bash
python3 -m pip install -r requirements.txt
```

## Covering calculations

```bash
cd covers
python3 verify_cover.py
python3 verify_lifting.py
```

The programs check the homomorphisms to S3 and S4, the thirteen covering
classes of degree four, their integral first homology, the central involution,
and two integer calculations of fiber divisibility. Keep `cs_group_input.json`
in the same directory as the scripts.

## Monodromy and pencil calculations

From the repository root:

```bash
cd monodromy
python3 check_node_tangent.py
python3 check_albanese_fox.py
python3 run_all.py
```

The original README in each directory describes its input data and computations.
Those READMEs retain references to earlier draft numbering. `run_all.py` does not
include the Fox-matrix check, which is run separately above.

The cover, lifting, node-tangent and Fox-matrix checks were rerun successfully
on October 17, 2026. The other programs are supplied unchanged from the original
verification archives. SHA-256 checksums are provided in `SHA256SUMS`.

These computations do not determine a complete marked monodromy factorization.
The polynomial input equations and coordinate forms are attributed to Borisov–Yeung
and Szabó in `monodromy/README.md`; the group presentation is identified in
`covers/cs_group_input.json`. Existing source attributions are retained.

For a journal submission, cite an immutable commit link or tagged release so
that the verification files match the submitted version of the manuscript.
