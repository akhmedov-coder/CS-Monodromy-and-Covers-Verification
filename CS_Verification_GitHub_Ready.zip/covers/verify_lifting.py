"""Exact checks for the fiber-divisibility and central-obstruction calculation.

This verifies finite algebraic data, not marked mapping-class monodromy.
Run with Python 3; no third-party packages are required.
"""
import json
from math import gcd
from pathlib import Path

data = json.loads((Path(__file__).parent / 'cs_group_input.json').read_text())
vectors = data['albanese_vectors']
expected_k = [1, -1, -1, 0, 0, 1, -1, 0, -1, 1, 1, 0, -2]
expected_areas = [40, 4, -8, 0, 20, 8, -12, 32, -36, -8, -60, 8, 0]
expected_central = [30, -8, -14, 0, 10, 14, -16, 16, -28, 6, -20, 4, -20]
expected_degrees = [22, 16, 0, 10, -16, 14, 16, 2, -24, -50, 4, 40]

def hmul(a, b):
    return a[0]+b[0], a[1]+b[1], a[2]+b[2]+a[0]*b[1]

def hinv(a):
    return -a[0], -a[1], -a[2]+a[0]*a[1]

areas, central, ks = [], [], []
for relator in data['relations']:
    x = y = area = 0
    exponent = [0, 0, 0]
    h = (0, 0, 0)
    for generator, power in relator:
        sign = 1 if power > 0 else -1
        dx, dy = (sign*t for t in vectors[generator])
        step = (*vectors[generator], 0)
        if sign < 0:
            step = hinv(step)
        for _ in range(abs(power)):
            area += x*dy-y*dx
            x, y = x+dx, y+dy
            exponent[generator] += sign
            h = hmul(h, step)
    assert (x, y) == (0, 0) == h[:2]
    k = exponent[1]//2
    assert exponent == [-3*k, 2*k, -7*k]
    ks.append(k)
    areas.append(area)
    central.append(h[2])
assert ks == expected_k
assert areas == expected_areas
assert central == expected_central
area_cycles = [areas[i]-ks[i]*areas[0] for i in range(1, 13)]
assert all(a % 2 == 0 for a in area_cycles)
degrees = [a//2 for a in area_cycles]
heisenberg_degrees = [central[i]-ks[i]*central[0] for i in range(1, 13)]
assert degrees == heisenberg_degrees == expected_degrees
assert gcd(*degrees) == 2

# A separate evaluation in the finite dihedral permutation quotient.
identity = (0, 1, 2, 3)
images = [(0, 1, 3, 2), (2, 3, 0, 1), (1, 0, 2, 3)]
def pmul(a, b):
    return tuple(a[b[i]] for i in range(4))

def pinv(a):
    return tuple(a.index(i) for i in range(4))

u = pmul(pmul(images[0], pinv(images[1])), pmul(images[2], images[2]))
v = pmul(images[1], pmul(u, u))
commutator = pmul(pmul(pmul(u, v), pinv(u)), pinv(v))
assert commutator == (1, 0, 3, 2)
assert commutator != identity
assert tuple(vectors[0][i]-vectors[1][i]+2*vectors[2][i] for i in range(2)) == (1, 0)
assert tuple(vectors[1][i]+2*(1, 0)[i] for i in range(2)) == (0, 1)

certificate = dict(exponent_multipliers=ks, doubled_polygon_areas=areas,
                   heisenberg_evaluations=central, cycle_degrees=degrees,
                   fiber_divisibility=gcd(*degrees),
                   central_commutator=list(commutator),
                   limitation='No marked mapping-class factorization is computed.')
(Path(__file__).parent / 'cs_lifting_certificate.json').write_text(
    json.dumps(certificate, indent=2)+'\n')
print('Both exact degree calculations agree: fiber divisibility is 2.')
print('The handle commutator is the nontrivial central involution.')
print('No marked mapping-class factorization is computed by this verifier.')
