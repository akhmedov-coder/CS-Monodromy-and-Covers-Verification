"""Exact CS cover verification. Run: python verify_cover.py.

Permutations act on the right: a letter takes sheet v to images[g][v].
The input contains the thirteen relators of Cartwright's presentation.
Requires SymPy for integral Smith normal forms.
"""
import itertools
import json
from collections import Counter, deque
from pathlib import Path
import sympy as sp
from sympy.matrices.normalforms import smith_normal_form

DATA = json.loads((Path(__file__).parent / "cs_group_input.json").read_text())
RELATORS = DATA["relations"]
assert len(RELATORS) == 13


def setup(n):
    perms = list(itertools.permutations(range(n)))
    index = {p: i for i, p in enumerate(perms)}
    identity = index[tuple(range(n))]
    mul = [[index[tuple(q[p[v]] for v in range(n))]
            for q in perms] for p in perms]
    inverse = [next(j for j in range(len(perms))
                    if mul[i][j] == identity) for i in range(len(perms))]
    return perms, index, identity, mul, inverse


def generated(gens, identity, mul):
    seen = {identity}
    pending = [identity]
    while pending:
        a = pending.pop()
        for b in gens:
            c = mul[a][b]
            if c not in seen:
                seen.add(c)
                pending.append(c)
    return seen


def enumerate_homs(n):
    perms, index, identity, mul, inverse = setup(n)
    exponents = {e for r in RELATORS for _, e in r}
    power = {}
    for g in range(len(perms)):
        for e in exponents:
            a = identity
            step = g if e >= 0 else inverse[g]
            for _ in range(abs(e)):
                a = mul[a][step]
            power[g, e] = a
    homs = []
    counts = Counter()
    for images in itertools.product(range(len(perms)), repeat=3):
        valid = True
        for relator in RELATORS:
            a = identity
            for g, e in relator:
                a = mul[a][power[images[g], e]]
            if a != identity:
                valid = False
                break
        if valid:
            group = generated(images, identity, mul)
            counts[len(group)] += 1
            homs.append((images, group))
    return (perms, index, identity, mul, inverse), homs, counts


def homology(images):
    n = len(images[0])
    inverse = [tuple(p.index(i) for i in range(n)) for p in images]
    d1 = sp.zeros(n, 3 * n)
    for v in range(n):
        for g in range(3):
            d1[images[g][v], 3 * v + g] += 1
            d1[v, 3 * v + g] -= 1
    d2 = sp.zeros(3 * n, n * len(RELATORS))
    for r, relator in enumerate(RELATORS):
        for v in range(n):
            current = v
            column = r * n + v
            for g, e in relator:
                for _ in range(abs(e)):
                    if e > 0:
                        d2[3 * current + g, column] += 1
                        current = images[g][current]
                    else:
                        previous = inverse[g][current]
                        d2[3 * previous + g, column] -= 1
                        current = previous
            assert current == v
    assert d1 * d2 == sp.zeros(n, n * len(RELATORS))
    adjacency = [[] for _ in range(n)]
    for v in range(n):
        for g in range(3):
            w = images[g][v]
            edge = 3 * v + g
            adjacency[v].append((w, edge))
            adjacency[w].append((v, edge))
    seen = {0}
    queue = deque([0])
    tree = []
    while queue:
        v = queue.popleft()
        for w, edge in adjacency[v]:
            if w not in seen:
                seen.add(w)
                queue.append(w)
                tree.append(edge)
    assert len(seen) == n and len(tree) == n - 1
    rows = [i for i in range(3 * n) if i not in tree]
    matrix = d2.extract(rows, list(range(d2.cols)))
    diagonal = smith_normal_form(matrix, domain=sp.ZZ)
    entries = [abs(int(diagonal[i, i])) for i in range(len(rows))]
    return entries, tree


vectors = DATA["albanese_vectors"]
for relator in RELATORS:
    assert all(sum(e * vectors[g][i] for g, e in relator) == 0
               for i in range(2))
abelian_relations = sp.Matrix([
    [sum(e for g, e in r if g == j) for j in range(3)]
    for r in RELATORS
])
abelian_smith = smith_normal_form(abelian_relations, domain=sp.ZZ)
assert [abs(int(abelian_smith[i, i])) for i in range(3)] == [1, 0, 0]

s3, homs3, counts3 = enumerate_homs(3)
assert dict(counts3) == {1: 1, 2: 9, 3: 8}
print("S3 homomorphisms: 18; no nonabelian image.")

s4, homs4, counts4 = enumerate_homs(4)
assert dict(counts4) == {1: 1, 2: 27, 3: 32, 4: 60, 8: 72}
perms, index, identity, mul, inverse = s4
images = [(0, 1, 3, 2), (2, 3, 0, 1), (1, 0, 2, 3)]
ids = tuple(index[p] for p in images)
assert ids in [h for h, _ in homs4]
group = generated(ids, identity, mul)
assert len(group) == 8
commutators = [
    mul[mul[mul[a][b]][inverse[a]]][inverse[b]]
    for a in group for b in group
]
derived = generated(commutators, identity, mul)
assert len(derived) == 2
orbits = {frozenset(perms[a][v] for a in derived) for v in range(4)}
assert orbits == {frozenset([0, 1]), frozenset([2, 3])}
entries, tree = homology(images)
assert entries == [1, 1, 1, 1, 1, 2, 2, 0, 0]
print("D8 cover H1: Z^2 + (Z/2)^2.")

intermediate = [(0, 1), (1, 0), (0, 1)]
entries2, _ = homology(intermediate)
assert entries2 == [1, 1, 2, 0, 0]
print("Intermediate base cover H1: Z^2 + Z/2.")

classes = {}
transitive_counts = Counter()
for h, group in homs4:
    if len({perms[a][0] for a in group}) != 4:
        continue
    transitive_counts[len(group)] += 1
    canonical = min(
        tuple(mul[mul[inverse[a]][x]][a] for x in h)
        for a in range(len(perms))
    )
    classes[canonical] = len(group)
assert dict(transitive_counts) == {4: 42, 8: 72}
assert Counter(classes.values()) == {4: 7, 8: 6}
base_types = Counter()
for h, order in classes.items():
    diag, _ = homology([perms[i] for i in h])
    if order == 8:
        assert diag == [1, 1, 1, 1, 1, 2, 2, 0, 0]
    else:
        base_types[tuple(x for x in diag if x > 1)] += 1
assert base_types == {(2, 4): 6, (2, 2, 2): 1}
print("Index-four cover classes: 7 Albanese base covers, 6 D8 covers.")
print("Base-cover torsion: Z/2 + Z/4 (six), (Z/2)^3 (one).")
print("All exact checks passed.")
