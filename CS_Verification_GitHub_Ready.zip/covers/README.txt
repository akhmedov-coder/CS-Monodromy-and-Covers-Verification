Dihedral covers of the Cartwright-Steger surface and genus-37 fibrations
Anar Akhmedov and Sai-Kee Yeung
Manuscript draft, October 14, 2026

Genus-37 Cartwright-Steger cover: exact verification

Run:
    python verify_cover.py

Dependency:
    sympy

The verifier checks the thirteen input group relators, exhaustively enumerates
homomorphisms to S3 and S4, verifies the explicit D8 covering action, computes
integral H1 directly from the lifted presentation complex, and classifies all
connected index-four covers up to covering equivalence.

The cover has base genus one, regular fiber genus 37, six singular values with
two nodes each, and twelve critical points in total. After local perturbation,
there are twelve distinct single-node singular fibers. Its invariants are
e=12, signature=4, chi_h=4, c1^2=36.

This is not a new genus-three surface bundle. No claim of literature priority
is made. The source presentation is identified in cs_group_input.json.

The other JSON files preserve separately obtained audit calculations.

Additional checks: run python3 verify_lifting.py for the central obstruction and two exact fiber-divisibility calculations. This does not compute a marked mapping-class factorization.

Section 7 constructs all finite cyclic groups at e=35, signature=1, and gives minimal nonspin exotic universal covers with free symplectic cyclic actions. Intermediate quotients give (e,signature)=(35k,k) for each fixed finite cyclic group. The application uses the regular Klein four base cover. Its geometric arguments are not certified by the arithmetic verifiers. Section 4 identifies two order-three symmetry orbits; Section 6 proves uniqueness of the invariant fiber character and the even-degree extension criterion. No smallest-known or literature-priority claim is made.
